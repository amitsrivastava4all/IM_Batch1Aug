const DELETE_ICON = "images/delete.png";
const EDIT_ICON = "images/edit.png";
const URL = "url";
const COLOR = "color";