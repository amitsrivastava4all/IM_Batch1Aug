function Item(id, name, descr, price, deldate, url, color){
	this.id = id ;
	this.name = name;
	this.descr = descr;
	this.price = price;
	this.deldate = deldate;
	this.url = url;
	this.color = color;
	this.isMarked= false;
}